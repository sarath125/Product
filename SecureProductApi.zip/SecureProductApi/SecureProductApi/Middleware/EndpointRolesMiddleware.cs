﻿//namespace SecureProduct.Api.Middleware
//{
//    public class EndpointRolesMiddleware
//    {
//        private readonly RequestDelegate _next;

//        public EndpointRolesMiddleware(RequestDelegate next)
//        {
//            _next = next;
//        }

//        public async Task Invoke(HttpContext context)
//        {
//            var endpoint = context.GetEndpoint();
//            if (endpoint != null)
//            {
//                var endpointRoles = endpoint.Metadata.GetOrderedMetadata<EndpointRolesAttribute>()
//                    .SelectMany(attr => attr.Roles)
//                    .Distinct();

//                if (endpointRoles.Any())
//                {
//                    var claimsIdentity = context.User.Identity as ClaimsIdentity;
//                    foreach (var role in endpointRoles)
//                    {
//                        claimsIdentity.AddClaim(new Claim(ClaimTypes.Role, role));
//                    }
//                }
//            }

//            await _next(context);
//        }
//    }

//}
