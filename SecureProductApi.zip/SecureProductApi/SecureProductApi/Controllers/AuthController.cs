﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SecureProduct.Core.Dtos;
using SecureProduct.Core.Interfaces;

namespace SecureProduct.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthRepository _authRepository;

        public AuthController(IAuthRepository authRepository)
        {
            _authRepository = authRepository;
        }

        [HttpPost("authenticate")]
        public IActionResult Authenticate([FromBody] LoginDto loginDto)
        {
            var token = _authRepository.Authenticate(loginDto.Username, loginDto.Password);

            if (string.IsNullOrEmpty(token))
                return Unauthorized("Username or password is incorrect.");

            return Ok(new { Token = token });
        }

    }
}
