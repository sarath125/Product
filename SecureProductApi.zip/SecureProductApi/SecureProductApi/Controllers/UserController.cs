﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SecureProduct.Api.Filters;
using SecureProduct.Core.DTOs;
using SecureProduct.Core.Interfaces;
using SecureProduct.Core.Models;
using Swashbuckle.AspNetCore.Annotations;

namespace SecureProduct.Api.Controllers
{
    /// <summary>
    /// Manages user operations.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin")]
    [ValidateModelAttribute]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="UserController"/> class.
        /// </summary>
        /// <param name="userRepository">The user repository.</param>
        public UserController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        /// <summary>
        /// Gets all users.
        /// </summary>
        /// <returns>A list of users.</returns>
        [HttpGet]
        [SwaggerResponse(StatusCodes.Status200OK, "Returns the list of users.", Type = typeof(IEnumerable<User>))]
        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
            var users = await _userRepository.GetUsersAsync();
            return Ok(users);
        }

        /// <summary>
        /// Gets a user by ID.
        /// </summary>
        /// <param name="id">The user ID.</param>
        /// <returns>The user with the specified ID.</returns>
        [HttpGet("{id}")]
        [SwaggerResponse(StatusCodes.Status200OK, "Returns the user with the specified ID.", Type = typeof(User))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "No user found with the specified ID.")]
        public async Task<ActionResult<User>> GetUser(int id)
        {
            var user = await _userRepository.GetUserByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(user);
        }

        /// <summary>
        /// Adds a new user.
        /// </summary>
        /// <param name="user">The user to add.</param>
        /// <returns>The created user.</returns>
        [HttpPost]
        [SwaggerResponse(StatusCodes.Status201Created, "The user has been created.", Type = typeof(User))]
        [SwaggerResponse(StatusCodes.Status400BadRequest, "The user data is invalid.")]
        public async Task<ActionResult<User>> AddUser([FromBody] CreateUserDto user)
        {
            var createdUser = await _userRepository.AddUserAsync(user);
            return CreatedAtAction(nameof(GetUser), new { id = createdUser.UserId }, createdUser);
        }

        /// <summary>
        /// Updates an existing user.
        /// </summary>
        /// <param name="id">The user ID.</param>
        /// <param name="user">The updated user information.</param>
        /// <returns>An action result indicating the outcome of the update operation.</returns>
        [HttpPut("{id}")]
        [SwaggerResponse(StatusCodes.Status200OK, "The user has been updated successfully.")]
        [SwaggerResponse(StatusCodes.Status400BadRequest, "The user ID in the URL does not match the user ID in the data.")]
        [SwaggerResponse(StatusCodes.Status404NotFound, "No user found with the specified ID.")]
        public async Task<IActionResult> UpdateUser(int id, [FromBody] UpdateUserDto user)
        {
            if (id != user.UserId)
            {
                return BadRequest("The user ID in the URL does not match the user ID in the data.");
            }

            var existingUser = await _userRepository.GetUserByIdAsync(id);
            if (existingUser == null)
            {
                return NotFound();
            }

            await _userRepository.UpdateUserAsync(user);
            return Ok("The user has been updated successfully.");
        }

        /// <summary>
        /// Deletes a user by ID.
        /// </summary>
        /// <param name="id">The user ID.</param>
        /// <returns>An action result indicating the outcome of the delete operation.</returns>
        [HttpDelete("{id}")]
        [SwaggerResponse(StatusCodes.Status200OK, "The user has been deleted successfully.")]
        [SwaggerResponse(StatusCodes.Status404NotFound, "No user found with the specified ID.")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var user = await _userRepository.GetUserByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            await _userRepository.DeleteUserAsync(id);
            return Ok("The user has been deleted successfully.");
        }
    }
}
