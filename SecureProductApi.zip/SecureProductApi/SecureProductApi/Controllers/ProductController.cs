﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SecureProduct.Core.DTOs;
using SecureProduct.Core.Interfaces;
using Swashbuckle.AspNetCore.Annotations;

namespace SecureProduct.Api.Controllers
{
    /// <summary>
    /// Manages product operations.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin,User")]
    public class ProductController : ControllerBase
    {
        private readonly IProductRepository _productRepository;
        private readonly IMapper _mapper;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductController"/> class.
        /// </summary>
        /// <param name="productRepository">The product repository.</param>
        /// <param name="mapper">The mapper.</param>
        public ProductController(IProductRepository productRepository, IMapper mapper)
        {
            _productRepository = productRepository;
            _mapper = mapper;
        }

        /// <summary>
        /// Retrieves all products.
        /// </summary>
        /// <returns>A list of products.</returns>
        [HttpGet]
        [SwaggerResponse(StatusCodes.Status200OK, "Returns the list of products.", Type = typeof(IEnumerable<ProductDto>))]
        [SwaggerResponse(StatusCodes.Status401Unauthorized, "Unauthorized access.")]
        public async Task<ActionResult<IEnumerable<ProductDto>>> GetProducts()
        {
            var products = await _productRepository.GetProductsAsync();
            var productDtos = _mapper.Map<IEnumerable<ProductDto>>(products);
            return Ok(productDtos);
        }

        /// <summary>
        /// Retrieves a specific product by unique ID.
        /// </summary>
        /// <param name="id">The product ID.</param>
        /// <returns>The product with the specified ID.</returns>
        [HttpGet("{id}")]
        [SwaggerResponse(StatusCodes.Status200OK, "Returns the product with the specified ID.", Type = typeof(ProductDto))]
        [SwaggerResponse(StatusCodes.Status404NotFound, "No product found with the specified ID.")]
        [SwaggerResponse(StatusCodes.Status401Unauthorized, "Unauthorized access.")]
        public async Task<ActionResult<ProductDto>> GetProduct(int id)
        {
            var product = await _productRepository.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound("No product found with the specified ID.");
            }
            var productDto = _mapper.Map<ProductDto>(product);
            return Ok(productDto);
        }

        /// <summary>
        /// Creates a new product.
        /// </summary>
        /// <param name="createProductDto">The product to create.</param>
        /// <returns>The created product.</returns>
        [HttpPost]
        [SwaggerResponse(StatusCodes.Status201Created, "The product has been created.", Type = typeof(ProductDto))]
        [SwaggerResponse(StatusCodes.Status400BadRequest, "The product data is invalid.")]
        [SwaggerResponse(StatusCodes.Status401Unauthorized, "Unauthorized access.")]
        [SwaggerResponse(StatusCodes.Status409Conflict, "A product with the same ProductId or Name already exists.")]
        public async Task<ActionResult<ProductDto>> AddProduct([FromBody] CreateProductDto createProduct)
        {
            // Check for duplicate ProductId or Name
            var existingProductByName = await _productRepository.GetProductByNameAsync(createProduct.Name);

            if (existingProductByName != null)
            {
                return Conflict("A product with the same ProductId or Name already exists.");
            }

            var createdProduct = await _productRepository.AddProductAsync(createProduct);
            var productDto = _mapper.Map<ProductDto>(createdProduct);
            return CreatedAtAction(nameof(GetProduct), new { id = createdProduct.ProductId }, productDto);
        }

        /// <summary>
        /// Updates an existing product.
        /// </summary>
        /// <param name="id">The product ID.</param>
        /// <param name="updateProductDto">The updated product.</param>
        /// <returns>No content.</returns>
        [HttpPut("{id}")]
        [SwaggerResponse(StatusCodes.Status204NoContent, "The product has been updated successfully.")]
        [SwaggerResponse(StatusCodes.Status400BadRequest, "The product ID in the URL does not match the product ID in the data.")]
        [SwaggerResponse(StatusCodes.Status401Unauthorized, "Unauthorized access.")]
        [SwaggerResponse(StatusCodes.Status404NotFound, "No product found with the specified ID.")]
        public async Task<IActionResult> UpdateProduct(int id, [FromBody] UpdateProductDto updateProduct)
        {
            if (id != updateProduct.ProductId)
            {
                return BadRequest("The product ID in the URL does not match the product ID in the data.");
            }

            var existingProduct = await _productRepository.GetProductByIdAsync(id);
            if (existingProduct == null)
            {
                return NotFound("No product found with the specified ID.");
            }

            await _productRepository.UpdateProductAsync(updateProduct);
            return NoContent();
        }

        /// <summary>
        /// Deletes a specific product by unique ID.
        /// </summary>
        /// <param name="id">The product ID.</param>
        /// <returns>No content.</returns>
        [HttpDelete("{id}")]
        [SwaggerResponse(StatusCodes.Status204NoContent, "The product has been deleted successfully.")]
        [SwaggerResponse(StatusCodes.Status404NotFound, "No product found with the specified ID.")]
        [SwaggerResponse(StatusCodes.Status401Unauthorized, "Unauthorized access.")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await _productRepository.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound("No product found with the specified ID.");
            }

            await _productRepository.DeleteProductAsync(id);
            return NoContent();
        }
    }
}
