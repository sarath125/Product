﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecureProduct.Core.DTOs
{
    public class UserDto
    {
        public string UserId { get; set; }
        public string UserName { get; set; }

        public string? Role { get; set; }
    }

    public class CreateUserDto
    {


        [Required(ErrorMessage = "Username is required.")]
        [StringLength(100, ErrorMessage = "Username must not exceed 100 characters.")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [StringLength(10, ErrorMessage = "Password must not exceed 10 characters.")]
        [DataType(DataType.Password)]
        public string PasswordHash { get; set; }

        [StringLength(5, ErrorMessage = "Role must not exceed 5 characters.")]
        [RegularExpression("^(Admin|User)$", ErrorMessage = "Role must be either 'Admin' or 'User'.")]
        public string? Role { get; set; }
    }

    public class UpdateUserDto
    {

        [Required(ErrorMessage = "User ID is required.")]       
        public int UserId { get; set; }

        [Required(ErrorMessage = "Username is required.")]
        [StringLength(100, ErrorMessage = "Username must not exceed 100 characters.")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [StringLength(255, ErrorMessage = "Password must not exceed 255 characters.")]
        [DataType(DataType.Password)]
        public string PasswordHash { get; set; }

        [StringLength(50, ErrorMessage = "Role must not exceed 50 characters.")]
        [RegularExpression("^(Admin|User)$", ErrorMessage = "Role must be either 'Admin' or 'User'.")]
        public string? Role { get; set; }
    }
}
