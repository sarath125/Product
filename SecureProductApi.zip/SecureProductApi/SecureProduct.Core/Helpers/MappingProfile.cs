﻿using AutoMapper;
using SecureProduct.Core.DTOs;
using SecureProduct.Core.Models;

namespace SecureProduct.Core.Helpers
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<User, UserDto>().ReverseMap();
            CreateMap<User, CreateUserDto>().ReverseMap().ForMember(dest => dest.UserId, opt => opt.Ignore());
            CreateMap<User, UpdateUserDto>().ReverseMap();

            CreateMap<Product, ProductDto>().ReverseMap();
            CreateMap<Product, CreateProductDto>().ReverseMap().ForMember(dest => dest.ProductId, opt => opt.Ignore());
            CreateMap<Product, UpdateProductDto>().ReverseMap();
        }
    }
}
