﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecureProduct.Core.Interfaces
{
    public interface IAuthRepository
    {
        string Authenticate(string username, string password);
    }
}
