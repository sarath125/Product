﻿using System;
using System.Collections.Generic;

namespace SecureProduct.Core.Models
{
    public partial class AuditLog
    {
        public int Id { get; set; }
        public string Action { get; set; } = null!;
        public string? Data { get; set; }
        public string UserName { get; set; } = null!;
        public DateTime Timestamp { get; set; }
    }
}
