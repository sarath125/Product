﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using SecureProduct.Core.Interfaces;
using SecureProduct.Infrastructure.Data;
using SecureProduct.Core.DTOs;
using SecureProduct.Core.Models;

namespace SecureProduct.Infrastructure.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly ProductDBContext _context;
        private readonly IMapper _mapper;
        private readonly IAuditLogger _auditLogger;

        public UserRepository(ProductDBContext context, IMapper mapper, IAuditLogger auditLogger)
        {
            _context = context;
            _mapper = mapper;
            _auditLogger = auditLogger;
        }

        public async Task<IEnumerable<UserDto>> GetUsersAsync()
        {
            var users = await _context.Users.ToListAsync();
            var userDtos = _mapper.Map<IEnumerable<UserDto>>(users);
            await _auditLogger.Log("GetUsers", "Retrieved all users");
            return userDtos;
        }

        public async Task<UserDto> GetUserByIdAsync(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user != null)
            {
                await _auditLogger.Log($"GetUserById: {id}", $"Retrieved user with ID {id}");
                return _mapper.Map<UserDto>(user);
            }
            return null;
        }

        public async Task<UserDto> AddUserAsync(CreateUserDto createUserDto)
        {
            var user = _mapper.Map<User>(createUserDto);
            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
            await _auditLogger.Log("AddUser", $"Added user with ID {user.UserId}");
            return _mapper.Map<UserDto>(user);
        }

        public async Task UpdateUserAsync(UpdateUserDto updateUserDto)
        {
            var user = await _context.Users.FindAsync(updateUserDto.UserId);
            if (user != null)
            {
                _mapper.Map(updateUserDto, user);
                _context.Users.Update(user);
                await _context.SaveChangesAsync();
                await _auditLogger.Log("UpdateUser", $"Updated user with ID {user.UserId}");
            }
        }

        public async Task DeleteUserAsync(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user != null)
            {
                _context.Users.Remove(user);
                await _context.SaveChangesAsync();
                await _auditLogger.Log("DeleteUser", $"Deleted user with ID {id}");
            }
        }
    }
}
