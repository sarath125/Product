﻿using Microsoft.IdentityModel.Tokens;
using SecureProduct.Core.Dtos;
using SecureProduct.Core.Interfaces;
using SecureProduct.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace SecureProduct.Infrastructure.Repositories
{
    public class AuthRepository : IAuthRepository
    {
        private readonly JwtConfig _jwtConfig;
        private readonly ProductDBContext _context;
        

        public AuthRepository(JwtConfig jwtConfig,ProductDBContext context)
        {
            _context = context;
            _jwtConfig = jwtConfig;
        }
       

        public string Authenticate(string username, string password)
        {
            var user = _context.Users.SingleOrDefault(x => x.Username.ToLower() == username.ToLower() && x.PasswordHash.ToLower() == password.ToLower());

            if (user == null)
                return null;

            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenKey = Encoding.ASCII.GetBytes(_jwtConfig.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
          {
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Role, user.Role)
          }),
                Expires = DateTime.UtcNow.AddMinutes(_jwtConfig.AccessTokenExpirationMinutes),
                Issuer = _jwtConfig.Issuer,
                Audience = _jwtConfig.Audience,
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(tokenKey), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
