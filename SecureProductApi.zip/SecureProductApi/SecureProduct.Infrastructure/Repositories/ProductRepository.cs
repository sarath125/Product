﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using SecureProduct.Core.Interfaces;
using SecureProduct.Infrastructure.Data;
using SecureProduct.Core.DTOs;
using System.Collections.Generic;
using System.Threading.Tasks;
using SecureProduct.Core.Models;

namespace SecureProduct.Infrastructure.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly ProductDBContext _context;
        private readonly IMapper _mapper;
        private readonly IAuditLogger _auditLogger;

        public ProductRepository(ProductDBContext context, IMapper mapper, IAuditLogger auditLogger)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<IEnumerable<ProductDto>> GetProductsAsync()
        {
            var products = await _context.Products.AsNoTracking().ToListAsync();
            await _auditLogger.Log("GetProducts", "Retrieved all Products");
            return _mapper.Map<IEnumerable<ProductDto>>(products);
        }

        public async Task<ProductDto> GetProductByIdAsync(int id)
        {
            var product = await _context.Products.AsNoTracking().FirstOrDefaultAsync(p => p.ProductId == id);
            if (product == null)
                return null;

            await _auditLogger.Log($"GetProductById: {id}", $"Retrieved Product with ID {id}");
            return _mapper.Map<ProductDto>(product);
        }

        public async Task<ProductDto> AddProductAsync(CreateProductDto createProductDto)
        {
            var product = _mapper.Map<Product>(createProductDto);
            await _context.Products.AddAsync(product);
            await _context.SaveChangesAsync();
            await _auditLogger.Log("AddProduct", $"Added Product with ID {product.ProductId}");
            return _mapper.Map<ProductDto>(product);
        }

        public async Task UpdateProductAsync(UpdateProductDto updateProductDto)
        {
            var product = await _context.Products.FirstOrDefaultAsync(p => p.ProductId == updateProductDto.ProductId);
            if (product == null)
                return;

            _mapper.Map(updateProductDto, product);
            _context.Products.Update(product);
            await _auditLogger.Log("UpdateProduct", $"Updated Product with ID {product.ProductId}");
            await _context.SaveChangesAsync();
        }

        public async Task DeleteProductAsync(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                _context.Products.Remove(product);
                await _context.SaveChangesAsync();
                await _auditLogger.Log("DeleteProduct", $"Deleted Product with ID {id}");
            }
        }

        public async Task<ProductDto> GetProductByNameAsync(string name)
        {
            var product = await _context.Products.AsNoTracking().SingleOrDefaultAsync(p => p.Name == name);
            if (product == null)
                return null;

            return _mapper.Map<ProductDto>(product);
        }
    }
}
