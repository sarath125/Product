﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using SecureProduct.Core.Interfaces;
using SecureProduct.Core.Models;
using SecureProduct.Infrastructure.Data;


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecureProduct.Infrastructure.Logging
{
    public class AuditLogger : IAuditLogger
    {
        private readonly ProductDBContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IMapper _mapper;

        public AuditLogger(ProductDBContext context, IHttpContextAccessor httpContextAccessor, IMapper mapper)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task Log(string action, string data)
        {
            var userName = _httpContextAccessor.HttpContext?.User?.Identity?.Name ?? "Unknown";
            var auditLog = new AuditLog
            {
                Action = action,
                Data = data,
                UserName = userName,
                Timestamp = DateTime.UtcNow
            };


            await _context.AuditLogs.AddAsync(auditLog);
            await _context.SaveChangesAsync();
        }
    }
}
